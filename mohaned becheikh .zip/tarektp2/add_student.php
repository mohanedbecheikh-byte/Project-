<?php
require __DIR__ . '/auth_check.php';
// add_student.php
// Shows a form (GET) and handles submission (POST) to add a student to students.json

function h($s){ return htmlspecialchars($s, ENT_QUOTES); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = trim($_POST['student_id'] ?? '');
    $name = trim($_POST['name'] ?? '');
    $group = trim($_POST['group'] ?? '');

    $errors = [];

    if ($student_id === '') { $errors[] = 'student_id is required.'; }
    if ($name === '') { $errors[] = 'name is required.'; }
    if ($group === '') { $errors[] = 'group is required.'; }

    $students_file = __DIR__ . '/students.json';
    $students = [];

    if (file_exists($students_file)) {
        $json = file_get_contents($students_file);
        $decoded = json_decode($json, true);
        if (is_array($decoded)) $students = $decoded;
    }

    // Check duplicate student_id
    foreach ($students as $s) {
        if (isset($s['student_id']) && $s['student_id'] === $student_id) {
            $errors[] = 'A student with this student_id already exists.';
            break;
        }
    }

    if (empty($errors)) {
        $students[] = [
            'student_id' => $student_id,
            'name' => $name,
            'group' => $group
        ];

        $saved = file_put_contents($students_file, json_encode($students, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

        if ($saved === false) {
            $errors[] = 'Failed to save students.json. Check file permissions.';
        } else {
            echo '<h2>Student added successfully</h2>';
            echo '<p>' . h($name) . ' (ID: ' . h($student_id) . ', Group: ' . h($group) . ')</p>';
            echo '<p><a href="add_student.php">Add another student</a> | <a href="take_attendance.php">Take attendance</a> | <a href="tp2.html">Back to homepage</a></p>';
            exit;
        }
    }

    // If we get here, there were errors
    echo '<h2>There were errors</h2>';
    echo '<ul>';
    foreach ($errors as $err) {
        echo '<li>' . h($err) . '</li>';
    }
    echo '</ul>';
    echo '<p><a href="add_student.php">Back to form</a></p>';
    exit;
}

// GET: show form
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<title>Add student</title>
<style>
body { font-family: Arial, sans-serif; padding: 20px; }
form { max-width: 480px; }
label { display:block; margin-top:10px; }
input[type=text] { width:100%; padding:8px; box-sizing:border-box; }
button { margin-top:12px; padding:8px 12px; }
</style>
</head>
<body>
<h1>Add student</h1>
<form method="post" action="add_student.php">
    <label>student_id: <input type="text" name="student_id" required></label>
    <label>name: <input type="text" name="name" required></label>
    <label>group: <input type="text" name="group" required></label>
    <button type="submit">Add student</button>
</form>
<p><a href="take_attendance.php">Take attendance</a> | <a href="tp2.html">Back to homepage</a></p>
</body>
</html>
