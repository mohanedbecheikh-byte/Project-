<?php
require __DIR__ . '/auth_check.php';
// take_attendance.php
// Shows students and radio buttons (present/absent). On submit, saves attendance_YYYY-MM-DD.json
function h($s){ return htmlspecialchars($s, ENT_QUOTES); }

$students_file = __DIR__ . '/students.json';

if (!file_exists($students_file)) {
    echo '<p>No students found. <a href="add_student.php">Add students first</a>.</p>';
    exit;
}

$students_raw = file_get_contents($students_file);
$students = json_decode($students_raw, true);
if (!is_array($students) || count($students) === 0) {
    echo '<p>No students found in students.json. <a href="add_student.php">Add students first</a>.</p>';
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $today = date('Y-m-d');
    $attendance_file = __DIR__ . '/attendance_' . $today . '.json';

    if (file_exists($attendance_file)) {
        echo '<h2>Attendance for today has already been taken.</h2>';
        echo '<p><a href="tp2.html">Back to homepage</a></p>';
        exit;
    }

    $statuses = $_POST['status'] ?? [];
    $attendance = [];

    foreach ($students as $s) {
        $id = $s['student_id'] ?? '';
        $status = 'absent';
        if (isset($statuses[$id]) && $statuses[$id] === 'present') {
            $status = 'present';
        }
        $attendance[] = ['student_id' => (string)$id, 'status' => $status];
    }

    $saved = file_put_contents($attendance_file, json_encode($attendance, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    if ($saved === false) {
        echo '<h2>Failed to save attendance file. Check permissions.</h2>';
    } else {
        echo '<h2>Attendance saved to ' . h(basename($attendance_file)) . '</h2>';
        echo '<pre>' . h(json_encode($attendance, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) . '</pre>';
    }
    echo '<p><a href="take_attendance.php">Back</a> | <a href="tp2.html">Homepage</a></p>';
    exit;
}

// GET: show form
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<title>Take attendance</title>
<style>
body { font-family: Arial, sans-serif; padding:20px; }
table { border-collapse: collapse; width:100%; max-width:800px; }
th, td { padding:8px 10px; border:1px solid #ddd; text-align:left; }
label { margin-right:10px; }
button { margin-top:12px; padding:8px 12px; }
</style>
</head>
<body>
<h1>Take attendance (<?php echo date('Y-m-d'); ?>)</h1>
<form method="post" action="take_attendance.php">
    <table>
        <thead>
            <tr><th>ID</th><th>Name</th><th>Group</th><th>Status</th></tr>
        </thead>
        <tbody>
        <?php foreach ($students as $s): 
            $id = isset($s['student_id']) ? $s['student_id'] : '';
            $name = isset($s['name']) ? $s['name'] : '';
            $group = isset($s['group']) ? $s['group'] : '';
        ?>
            <tr>
                <td><?php echo h($id); ?></td>
                <td><?php echo h($name); ?></td>
                <td><?php echo h($group); ?></td>
                <td>
                    <label><input type="radio" name="status[<?php echo h($id); ?>]" value="present" checked> Present</label>
                    <label><input type="radio" name="status[<?php echo h($id); ?>]" value="absent"> Absent</label>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <button type="submit">Save attendance for today</button>
</form>
<p><a href="add_student.php">Add student</a> | <a href="tp2.html">Back to homepage</a></p>
</body>
</html>
