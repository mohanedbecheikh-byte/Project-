<?php
require __DIR__ . '/auth_check.php';
function h($s){ return htmlspecialchars($s, ENT_QUOTES); }

$students_file = __DIR__ . '/students.json';
$students = [];
if (file_exists($students_file)) {
    $students = json_decode(file_get_contents($students_file), true) ?? [];
}

// find attendance files
$attendance_files = [];
foreach (glob(__DIR__ . '/attendance_*.json') as $f) {
    $attendance_files[] = basename($f);
}
rsort($attendance_files);

?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Dashboard — TP2</title>
<link rel="stylesheet" href="tp2.css">
</head>
<body>
<header class="site-header">
  <div class="container">
    <h1 class="brand">TP2 — Dashboard</h1>
    <nav class="nav">
      <a href="tp2.html">Home</a>
      <a href="add_student.php">Add Student</a>
      <a href="take_attendance.php">Take Attendance</a>
      <a href="logout.php">Logout (<?php echo h($_SESSION['user']); ?>)</a>
    </nav>
  </div>
</header>

<main class="container">
  <section class="card">
    <h2>Students (<?php echo count($students); ?>)</h2>
    <?php if (count($students) === 0): ?>
      <p>No students yet. <a href="add_student.php">Add one</a>.</p>
    <?php else: ?>
      <table class="table">
        <thead><tr><th>ID</th><th>Name</th><th>Group</th></tr></thead>
        <tbody>
        <?php foreach ($students as $s): ?>
          <tr>
            <td><?php echo h($s['student_id'] ?? ''); ?></td>
            <td><?php echo h($s['name'] ?? ''); ?></td>
            <td><?php echo h($s['group'] ?? ''); ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </section>

  <section class="card">
    <h2>Attendance files</h2>
    <?php if (empty($attendance_files)): ?>
      <p>No attendance files yet.</p>
    <?php else: ?>
      <ul>
        <?php foreach ($attendance_files as $f): ?>
          <li><a href="<?php echo h($f); ?>" target="_blank"><?php echo h($f); ?></a></li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </section>
</main>

<footer class="site-footer">
  <div class="container">Admin dashboard — TP2</div>
</footer>
</body>
</html>
