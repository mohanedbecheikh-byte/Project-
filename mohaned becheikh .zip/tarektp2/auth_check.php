<?php
// auth_check.php - include this at the top of pages that require login
session_start();

// Secure session settings (best-effort)
if (function_exists('ini_set')) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_strict_mode', 1);
}

// Check login
if (!isset($_SESSION['user']) || empty($_SESSION['user'])) {
    // Not logged in, redirect to login page
    header('Location: login.php');
    exit;
}
?>