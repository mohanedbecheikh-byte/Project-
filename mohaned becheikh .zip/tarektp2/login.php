<?php
// login.php - simple login system using users.json
session_start();
function h($s){ return htmlspecialchars($s, ENT_QUOTES); }

$users_file = __DIR__ . '/users.json';
$messages = [];

// If users.json doesn't exist, create a default admin user
if (!file_exists($users_file)) {
    $default = [
        ['username' => 'admin', 'password' => password_hash('admin123', PASSWORD_DEFAULT), 'role' => 'admin']
    ];
    file_put_contents($users_file, json_encode($default, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    $messages[] = 'A default admin user was created: username <strong>admin</strong> / password <strong>admin123</strong>. Please change it after login.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $messages[] = 'Both username and password are required.';
    } else {
        $users = json_decode(file_get_contents($users_file), true);
        $found = false;
        foreach ($users as $u) {
            if (isset($u['username']) && $u['username'] === $username) {
                $found = true;
                if (password_verify($password, $u['password'])) {
                    // Login success
                    session_regenerate_id(true);
                    $_SESSION['user'] = $username;
                    $_SESSION['role'] = $u['role'] ?? 'user';
                    header('Location: dashboard.php');
                    exit;
                } else {
                    $messages[] = 'Invalid credentials.';
                }
                break;
            }
        }
        if (!$found) $messages[] = 'User not found.';
    }
}

?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Login — TP2</title>
<link rel="stylesheet" href="tp2.css">
</head>
<body>
<header class="site-header">
  <div class="container">
    <h1 class="brand">TP2 — Attendance System</h1>
    <nav class="nav">
      <a href="tp2.html">Home</a>
      <a href="add_student.php">Add Student</a>
      <a href="take_attendance.php">Take Attendance</a>
    </nav>
  </div>
</header>

<main class="container card">
  <h2>Login</h2>
  <?php foreach ($messages as $m) { echo '<div class="info">'. $m .'</div>'; } ?>
  <form method="post" action="login.php" class="form">
    <label>Username
      <input type="text" name="username" required>
    </label>
    <label>Password
      <input type="password" name="password" required>
    </label>
    <div class="form-actions">
      <button type="submit">Login</button>
    </div>
  </form>
  <p class="muted">Default admin created if none existed. Change password after first login.</p>
</main>
<footer class="site-footer">
  <div class="container">Made with ♥ — Professional TP2</div>
</footer>
</body>
</html>
