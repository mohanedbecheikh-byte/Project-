/*
 * P2PChat - Peer-to-Peer Chat Application
 *
 * Copyright (c) 2014 Ahmed Samy  <f.fallen45@gmail.com>
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package p2pchat;

import java.awt.KeyEventDispatcher;
import java.awt.KeyboardFocusManager;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import java.io.IOException;

import java.util.Iterator;
import java.util.List;

import javax.swing.SwingUtilities;
import javax.swing.text.DefaultCaret;
import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import netlib.PeerInfo;

public class P2PChat extends JFrame
{
    private Peer peer;

    private JList<String> chatParticipants;
    private JTextArea chatTextArea;
    private JTextField chatTextField;
    private JList<String> peerList;

    private JPopupMenu chatParticipantsPopup;
    private JPopupMenu peerListPopup;

    private final DefaultListModel<String> peerListModel;
    private final DefaultListModel<String> chatParticipantsModel;

    private String centralHost;
    private int centralPort;

    private boolean hasPublishedSelf;

    private static P2PChat instance;

    @SuppressWarnings("LeakingThisInConstructor")
    public P2PChat(String nick, String host, int port)
    {
        try {
            peer = new Peer(null, nick, host, port);
        } catch (IOException e) {
            e.printStackTrace();
        }

        peerListModel = new DefaultListModel<>();
        chatParticipantsModel = new DefaultListModel<>();

        instance = this;
        initComponents();

        DefaultCaret caret = (DefaultCaret) chatTextArea.getCaret();
        caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);

        chatTextArea.setLineWrap(true);
        chatTextArea.append(
            "Welcome to P2P Chat!\n" +
            "Commands:\n" +
            "  /help - Show help\n" +
            "  /nick <name> - Change nickname\n" +
            "  /kick <name> - Kick user\n" +
            "  /connect <host> <port> - Connect to peer\n"
        );

        KeyEventDispatcher toggleVoiceDispatcher = new KeyEventDispatcher() {
            @Override
            public boolean dispatchKeyEvent(KeyEvent e) {
                switch (e.getKeyCode()) {
                case KeyEvent.VK_T:
                    chatTextArea.append("Voice chat is disabled in this version.\n");
                    return true;
                case KeyEvent.VK_F1: {
                    chatTextArea.append("Voice settings are disabled in this version.\n");
                    return true;
                } default:
                    return false;
                }
            }
        };

        KeyboardFocusManager.getCurrentKeyboardFocusManager()
            .addKeyEventDispatcher(toggleVoiceDispatcher);
    }

    public static P2PChat get()
    {
        return instance;
    }

    public void setCentralInfo(String host, int port)
    {
        centralHost = host;
        centralPort = port;

        hasPublishedSelf = peer.publishSelf(host, port);
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {
        JScrollPane jScrollPane1 = new JScrollPane();
        JScrollPane jScrollPane4 = new JScrollPane();
        JScrollPane jScrollPane3 = new JScrollPane();

        JButton findPeersButton = new JButton("Find peers");
        JButton sendButton = new JButton("Send");

        chatParticipants = new JList<>();
        peerList = new JList<>();

        chatTextArea = new JTextArea();
        chatTextField = new JTextField();
        chatTextArea.setEditable(false);
        chatTextArea.setColumns(20);
        chatTextArea.setRows(5);
        jScrollPane1.setViewportView(chatTextArea);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        chatTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                if (evt.getKeyCode() == KeyEvent.VK_ENTER)
                    sendTextMessage();
            }
        });

        findPeersButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findPeersButtonActionPerformed(evt);
            }
        });

        chatParticipants.setModel(chatParticipantsModel);
        chatParticipants.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                chatParticipantsMouseClicked(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                if (evt.isPopupTrigger())
                    chatParticipantsPopup.show(evt.getComponent(), evt.getX(), evt.getY());
            }
        });
        jScrollPane3.setViewportView(chatParticipants);

        peerList.setModel(peerListModel);
        peerList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                peerListMouseClicked(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                if (evt.isPopupTrigger())
                    peerListPopup.show(evt.getComponent(), evt.getX(), evt.getY());
            }
        });
        jScrollPane4.setViewportView(peerList);

        sendButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                sendTextMessage();
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(chatTextField)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 452, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(sendButton, javax.swing.GroupLayout.DEFAULT_SIZE, 93, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(findPeersButton, javax.swing.GroupLayout.DEFAULT_SIZE, 91, Short.MAX_VALUE)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 371, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.LEADING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(findPeersButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(chatTextField)
                    .addComponent(sendButton)))
        );

        peerListPopup = new JPopupMenu("Action...");
        JMenuItem mItemDisconnect = new JMenuItem("Disconnect");
        mItemDisconnect.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String peerInfo = (String) peerList.getSelectedValue();
                if (peerInfo == null)
                    return;

                String peerHost = peerInfo.substring(0, peerInfo.indexOf(":"));
                if (peer.disconnectFrom(peerHost))
                    chatTextArea.append("<Network> Successfully disconnected from: " + peerHost + "\n");
            }
        });

        JMenuItem mItemConnect = new JMenuItem("Connect");
        mItemConnect.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String hostName = JOptionPane.showInputDialog("Hostname/IP:");
                String portName = JOptionPane.showInputDialog("Port:");

                int port;
                try {
                    port = Integer.parseInt(portName);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid port name " + portName + "!");
                    return;
                }

                try {
                    peer.connect(hostName, port);
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(null, "Unable to establish a connection to " + hostName + ":" + portName + "!");
                }

                peerListModel.addElement(hostName + ":" + port);
            }
        });
        peerListPopup.add(mItemConnect);
        peerListPopup.add(mItemDisconnect);

        chatParticipantsPopup = new JPopupMenu("Action...");
        JMenuItem mItemKick = new JMenuItem("Kick");
        mItemKick.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                String nickName = (String) chatParticipants.getSelectedValue();
                if (nickName != null)
                    peer.kick(nickName);
            }
        });
        chatParticipantsPopup.add(mItemKick);
        pack();
    }

    private void sendTextMessage()
    {
        String message = chatTextField.getText();
        if ("".equals(message))
            return;

        if (message.charAt(0) == '/') {
            String[] splitted = message.split(" ");
            if (splitted.length > 1) {
                if (splitted[0].equals("/nick")) {
                    // A Nickname can contain spaces
                    String newNick = new String();
                    for (int i = 1; i < splitted.length; ++i)
                        newNick += splitted[i] + " ";

                    peer.setName(newNick);
                    chatTextField.setText("");
                    chatTextArea.append("You changed your name to " + newNick + ".\n");
                } else if (splitted[0].equals("/kick")) {
                    // A Nickname can contain spaces
                    String nick = new String();
                    for (int i = 1; i < splitted.length; ++i)
                        nick += splitted[i] + " ";

                    if (peerListModel.contains(nick))
                        peer.kick(nick);
                } else if (splitted[0].equals("/connect")) {
                    String host = splitted[1];
                    int port = 9119;
                    if (splitted.length > 2)
                        port = Integer.parseInt(splitted[2]);

                    try {
                        chatTextArea.append("Attempting connection to " + host + ":" + port + "\n");
                        peer.connect(host, port);
                    } catch (IOException e) {
                        chatTextArea.append("Unable to connect to: " + host + ":" + port + "\n");
                        e.printStackTrace();
                    }
                } else
                    chatTextArea.append("Invalid command.\n");
            } else if (splitted[0].equals("/help")) {
                chatTextArea.append("Commands available:\n" +
                    "/nick <new nickname> (Can contain spaces)\n" +
                    "/kick <nickname> (Can contain spaces)\n" +
                    "/connect <host> <port>\n"
                );
            }

            return;
        }

        String selected = (String) chatParticipants.getSelectedValue();
        if (selected != null)
            peer.sendMessage(message, selected);
        else
            peer.sendMessage(message, (Peer) null);

        chatTextField.setText("");
        chatTextArea.append("<" + peer.peerName + "> " + message + "\n");
    }

    private void findPeersButtonActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (!hasPublishedSelf)
            hasPublishedSelf = peer.publishSelf(centralHost, centralPort);

        List<?> peers = peer.discoverPeers(centralHost, centralPort);
        if (peers == null) {
            chatTextArea.append("No peers were found.\n");
            return;
        }
        peerListModel.clear();

        Iterator<?> it = peers.iterator();
        while (it.hasNext()) {
            PeerInfo info = (PeerInfo) it.next();
            peerListModel.addElement(info.host + ":" + info.port);
        }
    }

    private void peerListMouseClicked(java.awt.event.MouseEvent evt)
    {
        if (SwingUtilities.isLeftMouseButton(evt)) {
            String peerInfo = (String) peerList.getSelectedValue();
            if (peerInfo == null)
                return;

            int sep = peerInfo.indexOf(":");
            String peerHost = peerInfo.substring(0, sep);
            int peerPort = Integer.parseInt(peerInfo.substring(sep + 1, peerInfo.length()));

            try {
                peer.connect(peerHost, peerPort);
            } catch (IOException e) {
                chatTextArea.append("Unable to connect to: " + peerInfo + "\n");
                e.printStackTrace();
            }
        } else if (evt.isPopupTrigger())
            peerListPopup.show(evt.getComponent(), evt.getX(), evt.getY());
    }

    private void chatParticipantsMouseClicked(java.awt.event.MouseEvent evt)
    {
        String selected = (String) chatParticipants.getSelectedValue();
        if (selected != null)
            chatTextArea.append("You're now private messaging " + selected + " (CTRL+LCLICK to unselect)\n");
        else
            chatTextArea.append("You're now broadcasting to everyone.\n");

        if (evt.isPopupTrigger())
            chatParticipantsPopup.show(evt.getComponent(), evt.getX(), evt.getY());
    }

    public void appendText(String sender, String text)
    {
        if (sender == null)
            sender = "Network";

        chatTextArea.append("<" + sender + "> " + text + "\n");
    }

    public void peerConnected(Peer newPeer)
    {
        if (newPeer.peerName == null)
            newPeer.peerName = "unnamed";

        chatTextArea.append(newPeer.peerName + " has connected.\n");
        chatParticipantsModel.addElement(newPeer.peerName);
    }

    public void peerDisconnected(Peer node, boolean timeout)
    {
        int idx = chatParticipantsModel.indexOf(node.peerName);
        if (idx != -1)
            chatParticipantsModel.remove(idx);

        if (!timeout)
            chatTextArea.append(node.peerName + " has disconnected.\n");
        else
            chatTextArea.append(node.peerName + " has timed out.\n");
    }

    public void peerNameChanged(Peer node, String oldName, String newName)
    {
        int index = chatParticipantsModel.indexOf(oldName);
        if (index != -1) {
            if (peer.isChild(node)) {
                while (chatParticipantsModel.contains(newName) || newName.equals(peer.peerName)) {
                    newName += "_";
                    node.peerName = newName;
                    peer.sendNameChangeRequest(node);
                }
            }

            chatParticipantsModel.setElementAt(newName, index);
            chatTextArea.append(oldName + " has changed name to " + newName + "\n");
        } else {
            System.out.println("Unable to find peer name " + oldName + " (" + newName + ")");
            chatParticipantsModel.addElement(newName);
        }
    }

    public void peerAcked(String from, String hostName, int port)
    {
        if (!peerListModel.contains(hostName + ":" + port)) {
            chatTextArea.append("New Peer Acked from " + from + ": " + hostName + ":" + port + "\n");
            peerListModel.addElement(hostName + ":" + port);
        }
    }

    public void centralConnectionFailed()
    {
        chatTextArea.append("Unable to establish a connection to the central server.\n");
    }
}