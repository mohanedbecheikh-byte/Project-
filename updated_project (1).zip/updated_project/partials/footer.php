</div>
</main>
</div>
<script>
(function(){
 const side=document.getElementById('appSidebar');
 const btn=document.getElementById('collapseBtn');
 btn&&btn.addEventListener('click',()=>side.classList.toggle('collapsed'));
})();
</script>
</body>
</html>
