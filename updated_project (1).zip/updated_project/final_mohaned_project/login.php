<?php
session_start();
require 'db.php';

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $user = trim($_POST['username']);
    $pass = trim($_POST['password']);

    $stmt = $conn->prepare("SELECT id, username, password FROM users WHERE username=? LIMIT 1");
    $stmt->bind_param("s", $user);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $data = $result->fetch_assoc();
        if (password_verify($pass, $data['password'])) {
            $_SESSION['user'] = $data['username'];
            header("Location: dashboard.php");
            exit;
        } else {
            $error = "Incorrect password";
        }
    } else {
        $error = "User not found";
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login</title>
<style>
:root {
  --bg:#f4f6f8; --card:#ffffff; --primary:#0d6efd; --accent:#10b981;
  --danger:#ef4444; --text:#111827; --muted:#6b7280;
}
body{
  margin:0; padding:0;
  font-family:Inter,Segoe UI,Roboto,Arial,sans-serif;
  background:var(--bg);
  display:flex; align-items:center; justify-content:center;
  height:100vh;
  background-color: lightblue
}
.card{
  width:350px;
  background:var(--card);
  padding:30px;
  border-radius:18px;
  box-shadow:0 10px 30px rgba(2,6,23,0.12);
  animation:slideIn .6s ease;
}
@keyframes slideIn {
  0%{opacity:0;transform:translateY(40px);}
  100%{opacity:1;transform:translateY(0);}
}
h2{margin:0 0 20px;font-size:24px;text-align:center;}
input{
  width:100%;padding:12px;margin-bottom:12px;
  border:1px solid #ddd;border-radius:10px;
  font-size:15px;
}
button{
  width:100%;padding:12px;
  background:var(--primary);color:white;
  border:none;border-radius:10px;font-size:16px;
  cursor:pointer;transition:.2s;
}
button:hover{background:#0b5ed7;}
.error{
  background:var(--danger);color:white;
  padding:10px;border-radius:8px;
  text-align:center;margin-bottom:15px;
}
a{color:var(--primary);text-decoration:none;font-weight:600;}
a:hover{text-decoration:underline;}
</style>
</head>
<body>

<div class="card">
  <h2>Login</h2>

  <?php if ($error != ""): ?>
  <div class="error"><?php echo $error; ?></div>
  <?php endif; ?>

  <form method="POST">
    <input type="text" name="username" placeholder="Username" required>

    <input type="password" name="password" placeholder="Password" required>

    <button type="submit">Login</button>
  </form>

  <p style="text-align:center;margin-top:15px;">
    No account? <a href="register.php">Register</a>
  </p>
</div>

</body>
</html>
