<?php
require 'db.php';

$class_id = $_GET['class_id'];

$stmt = $conn->prepare("SELECT id, full_name FROM students WHERE class_id=?");
$stmt->bind_param("i", $class_id);
$stmt->execute();
$result = $stmt->get_result();

echo '<option value="">-- Select Student --</option>';
while($row = $result->fetch_assoc()) {
    echo '<option value="'.$row['id'].'">'.$row['full_name'].'</option>';
}
?>
