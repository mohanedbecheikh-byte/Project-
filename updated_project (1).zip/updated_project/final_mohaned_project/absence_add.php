<?php
if (session_status() == PHP_SESSION_NONE) session_start();
require 'db.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

// Récupérer étudiants et matières pour le formulaire
$students = $conn->query("SELECT id, full_name FROM students ORDER BY full_name ASC");
$subjects = $conn->query("SELECT id, subject_name FROM subjects ORDER BY subject_name ASC");

// Ajouter une absence
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = (int)$_POST['student_id'];
    $subject_id = (int)$_POST['subject_id'];
    $date = $_POST['date'];
    $note = trim($_POST['note']);

    $stmt = $conn->prepare("INSERT INTO absences(student_id, subject_id, date, note) VALUES(?,?,?,?)");
    $stmt->bind_param("iiss", $student_id, $subject_id, $date, $note);
    $stmt->execute();
    header("Location: absence_list.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Add Absence</title>
<style>
/* Même style que dashboard */
:root{
  --bg:#f4f6f8; --card:#ffffff; --muted:#6b7280; --primary:#0d6efd; --accent:#10b981; --danger:#ef4444; --text:#111827;
}
body.dark{--bg:#0b1220;--card:#071025;--muted:#94a3b8;--primary:#60a5fa;--accent:#34d399;--danger:#fb7185;--text:#e6eef8;}
*{box-sizing:border-box} html,body{height:100%;margin:0;font-family:Inter,Segoe UI,Roboto,Arial,sans-serif;background:var(--bg);color:var(--text);}
.container{display:flex;min-height:100vh;}
.sidebar{position:fixed;left:0;top:0;bottom:0;width:260px;background:linear-gradient(180deg, rgba(255,255,255,0.03), rgba(255,255,255,0.01));backdrop-filter: blur(6px);transform:translateX(-320px);transition:transform .28s ease, box-shadow .28s;padding:22px;z-index:40;box-shadow: 0 10px 30px rgba(2,6,23,0.18);}
.sidebar.open{transform:translateX(0);}
.brand{display:flex;align-items:center;gap:12px;margin-bottom:18px}
.brand .logo{width:46px;height:46px;border-radius:10px;background:linear-gradient(135deg,var(--primary),var(--accent));display:flex;align-items:center;justify-content:center;color:white;font-weight:700}
.brand h3{margin:0;font-size:18px}
.sidebar .nav{margin-top:12px;display:flex;flex-direction:column;gap:8px}
.nav a{display:flex;align-items:center;gap:12px;padding:12px;border-radius:10px;color:var(--text);text-decoration:none;font-weight:600;transition:background .18s,color .18s,transform .12s;}
.nav a svg{width:20px;height:20px;opacity:0.9}
.nav a:hover{background:rgba(255,255,255,0.04);transform:translateX(4px)}
.nav a.active{background:var(--primary);color:white;box-shadow:0 6px 18px rgba(13,110,253,0.12)}
.sidebar .closeBtn{position:absolute;right:-46px;top:14px;background:var(--card);border-radius:10px;padding:10px;box-shadow:0 6px 18px rgba(2,6,23,0.12);cursor:pointer}
.main{margin-left:0;width:100%;padding:26px;transition:margin-left .28s ease;min-height:100vh;}
.sidebar.open ~ .main{margin-left:260px}
.topbar{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:18px}
.top-left{display:flex;align-items:center;gap:12px}
.menuBtn{background:var(--card);border-radius:10px;padding:10px;cursor:pointer;box-shadow:0 6px 18px rgba(2,6,23,0.06)}
.userBox{display:flex;align-items:center;gap:12px}
.userAvatar{width:44px;height:44px;border-radius:10px;background:linear-gradient(135deg,var(--primary),var(--accent));display:flex;align-items:center;justify-content:center;color:white;font-weight:700}
.card{background:var(--card);padding:20px;border-radius:14px;box-shadow:0 6px 24px rgba(2,6,23,0.06);margin-top:20px;}
.add-btn{padding:10px 16px;background:var(--primary);color:#fff;border:none;border-radius:8px;cursor:pointer;margin-bottom:12px;}
.add-btn:hover{background:#0b5ed7;}
input,select,textarea{width:100%;padding:10px;margin-bottom:12px;border-radius:8px;border:1px solid #ddd;}
</style>
</head>
<body>
<div class="container">
  <aside class="sidebar" id="sidebar">
    <div class="brand"><div class="logo">AS</div><h3>AbsenceSys</h3></div>
    <div class="nav">
      <a href="dashboard.php" title="Dashboard">Dashboard</a>
      <a href="classes.php" title="Classes">Classes</a>
      <a href="students.php" title="Students">Students</a>
      <a href="subjects.php" title="Subjects">Subjects</a>
      <a href="absence_add.php" class="active" title="Add absence">Add Absence</a>
      <a href="absence_list.php" title="View absences">View Absences</a>
      <a href="logout.php" title="Logout" style="color:var(--danger);margin-top:10px;">Logout</a>
    </div>
    <div class="closeBtn" id="closeSidebar">X</div>
  </aside>
  <main class="main">
    <div class="topbar">
      <div class="top-left">
        <div class="menuBtn" id="openSidebar">&#9776;</div>
        <h2 style="margin:0">Add Absence</h2>
      </div>
      <div class="userBox">
        <div><?php echo htmlspecialchars($_SESSION['user']); ?></div>
        <div class="userAvatar"><?php echo strtoupper(substr($_SESSION['user'],0,1)); ?></div>
      </div>
    </div>

    <div class="card">
      <form method="POST">
        <label>Student:</label>
        <select name="student_id" required>
          <?php while($s = $students->fetch_assoc()): ?>
            <option value="<?php echo $s['id']; ?>"><?php echo htmlspecialchars($s['full_name']); ?></option>
          <?php endwhile; ?>
        </select>

        <label>Subject:</label>
        <select name="subject_id" required>
          <?php while($sub = $subjects->fetch_assoc()): ?>
            <option value="<?php echo $sub['id']; ?>"><?php echo htmlspecialchars($sub['subject_name']); ?></option>
          <?php endwhile; ?>
        </select>

        <label>Date:</label>
        <input type="date" name="date" required>

        <label>Note:</label>
        <textarea name="note"></textarea>

        <button class="add-btn" type="submit">Add Absence</button>
      </form>
    </div>
  </main>
</div>

<script>
var sidebar = document.getElementById('sidebar');
document.getElementById('openSidebar').addEventListener('click', function(){ sidebar.classList.toggle('open'); });
document.querySelector('.closeBtn').addEventListener('click', function(){ sidebar.classList.remove('open'); });
</script>
</body>
</html>
