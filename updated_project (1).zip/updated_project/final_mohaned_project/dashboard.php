<?php
// dashboard.php — version compatible (sans opérateurs PHP7-only)
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require 'db.php';

// Vérifier session
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

// Helper pour safe count query
function safe_count($conn, $sql) {
    $res = $conn->query($sql);
    if ($res) {
        $row = $res->fetch_assoc();
        if ($row && isset($row['c'])) return (int)$row['c'];
    }
    return 0;
}

// Comptages (compatibles)
$total_classes  = safe_count($conn, "SELECT COUNT(*) as c FROM classes");
$total_students = safe_count($conn, "SELECT COUNT(*) as c FROM students");
$total_subjects = safe_count($conn, "SELECT COUNT(*) as c FROM subjects");
$total_absences = safe_count($conn, "SELECT COUNT(*) as c FROM absences");

// Absences par classe
$class_labels = array();
$class_counts = array();
$class_data_q = "
    SELECT classes.class_name, COUNT(absences.id) as total
    FROM classes
    LEFT JOIN students ON students.class_id = classes.id
    LEFT JOIN absences ON absences.student_id = students.id
    GROUP BY classes.id
";
$res = $conn->query($class_data_q);
if ($res) {
    while ($r = $res->fetch_assoc()) {
        $class_labels[] = $r['class_name'];
        $class_counts[] = (int)$r['total'];
    }
}

// Absences par matière
$subject_labels = array();
$subject_counts = array();
$subject_data_q = "
    SELECT subjects.subject_name, COUNT(absences.id) as total
    FROM subjects
    LEFT JOIN absences ON absences.subject_id = subjects.id
    GROUP BY subjects.id
";
$res2 = $conn->query($subject_data_q);
if ($res2) {
    while ($r = $res2->fetch_assoc()) {
        $subject_labels[] = $r['subject_name'];
        $subject_counts[] = (int)$r['total'];
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Dashboard — Système d'absence</title>

<!-- Chart.js CDN -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
:root{
  --bg:#f4f6f8;
  --card:#ffffff;
  --muted:#6b7280;
  --primary:#0d6efd;
  --accent:#10b981;
  --danger:#ef4444;
  --text:#111827;
}
body.dark{
  --bg:#0b1220;
  --card:#071025;
  --muted:#94a3b8;
  --primary:#60a5fa;
  --accent:#34d399;
  --danger:#fb7185;
  --text:#e6eef8;
}
*{box-sizing:border-box}
html,body{height:100%;margin:0;font-family:Inter,Segoe UI,Roboto,Arial,sans-serif;background:var(--bg);color:var(--text);background-color: lightblue}
.container{display:flex;min-height:100vh;}
.sidebar{position:fixed;left:0;top:0;bottom:0;width:260px;background:linear-gradient(180deg, rgba(255,255,255,0.03), rgba(255,255,255,0.01));backdrop-filter: blur(6px);transform:translateX(-320px);transition:transform .28s ease, box-shadow .28s;padding:22px;z-index:40;box-shadow: 0 10px 30px rgba(2,6,23,0.18);}
.sidebar.open{transform:translateX(0);}
.brand{display:flex;align-items:center;gap:12px;margin-bottom:18px}
.brand .logo{width:46px;height:46px;border-radius:10px;background:linear-gradient(135deg,var(--primary),var(--accent));display:flex;align-items:center;justify-content:center;color:white;font-weight:700}
.brand h3{margin:0;font-size:18px}
.sidebar .nav{margin-top:12px;display:flex;flex-direction:column;gap:8px}
.nav a{display:flex;align-items:center;gap:12px;padding:12px;border-radius:10px;color:var(--text);text-decoration:none;font-weight:600;transition:background .18s,color .18s,transform .12s;}
.nav a svg{width:20px;height:20px;opacity:0.9}
.nav a:hover{background:rgba(255,255,255,0.04);transform:translateX(4px)}
.nav a.active{background:var(--primary);color:white;box-shadow:0 6px 18px rgba(13,110,253,0.12)}
.sidebar .closeBtn{position:absolute;right:-46px;top:14px;background:var(--card);border-radius:10px;padding:10px;box-shadow:0 6px 18px rgba(2,6,23,0.12);cursor:pointer}
.main{margin-left:0;width:100%;padding:26px;transition:margin-left .28s ease;min-height:100vh;}
.sidebar.open ~ .main{margin-left:260px}
.topbar{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:18px}
.top-left{display:flex;align-items:center;gap:12px}
.menuBtn{background:var(--card);border-radius:10px;padding:10px;cursor:pointer;box-shadow:0 6px 18px rgba(2,6,23,0.06)}
.userBox{display:flex;align-items:center;gap:12px}
.userAvatar{width:44px;height:44px;border-radius:10px;background:linear-gradient(135deg,var(--primary),var(--accent));display:flex;align-items:center;justify-content:center;color:white;font-weight:700}
.grid{display:grid;grid-template-columns: repeat(auto-fit,minmax(220px,1fr));gap:18px;margin-bottom:20px}
.card{background:var(--card);padding:20px;border-radius:14px;box-shadow:0 6px 24px rgba(2,6,23,0.06)}
.menuTile{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;padding:28px;border-radius:12px;text-decoration:none;color:var(--text);background:linear-gradient(180deg, transparent, rgba(0,0,0,0.01));transition:transform .12s ease,box-shadow .12s ease,background .12s;text-align:center;font-weight:700;min-height:120px;}
.menuTile:hover{transform:translateY(-6px);box-shadow:0 12px 30px rgba(2,6,23,0.08);background:rgba(0,0,0,0.02)}
.menuTile .count{font-size:28px;color:var(--primary);}
.chart-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:18px;margin-top:12px}
.chart-card{background:var(--card);padding:20px;border-radius:12px;box-shadow:0 8px 30px rgba(2,6,23,0.06);min-height:260px;display:flex;flex-direction:column;gap:10px;}
.chart-card h3{margin:0;font-size:16px;color:var(--muted)}
@media (max-width:900px){.sidebar{width:220px}.sidebar.open ~ .main{margin-left:220px}.menuTile{min-height:100px;padding:18px}.chart-card{min-height:220px}}
@media (max-width:600px){.brand h3{display:none}.userAvatar{width:36px;height:36px}.topbar{flex-direction:column;align-items:flex-start;gap:8px}.sidebar .closeBtn{right:-42px}}
</style>
</head>
<body>

<div class="container">
  <!-- SIDEBAR -->
  <aside class="sidebar" id="sidebar">
    <div class="brand">
      <div class="logo">AS</div>
      <h3>AbsenceSys</h3>
    </div>

    <div class="nav">
      <a href="dashboard.php" class="active" title="Dashboard">
        <svg viewBox="0 0 24 24" fill="currentColor"><path d="M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z"/></svg>
        Dashboard
      </a>

      <a href="classes.php" title="Classes">
        <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L1 7l11 5 9-4.09V17h2V7L12 2z"/></svg>
        Classes
      </a>

      <a href="students.php" title="Students">
        <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
        Students
      </a>

      <a href="subjects.php" title="Subjects">
        <svg viewBox="0 0 24 24" fill="currentColor"><path d="M21 3H3v2h18V3zM3 19h18v-2H3v2zM3 7h18v10H3V7z"/></svg>
        Subjects
      </a>

      <a href="absence_add.php" title="Add absence">
        <svg viewBox="0 0 24 24" fill="currentColor"><path d="M19 3h-1V1h-2v2H8V1H6v2H5c-1.1 0-2 .9-2 2v14a2 2 0 002 2h14a2 2 0 002-2V5c0-1.1-.9-2-2-2zM7 12h10v2H7z"/></svg>
        Add Absence
      </a>

      <a href="absence_list.php" title="View absences">
        <svg viewBox="0 0 24 24" fill="currentColor"><path d="M3 13h8v-2H3v2zm0 6h8v-2H3v2zM3 7h8V5H3v2zm10 6h8v-2h-8v2zm0 6h8v-2h-8v2z"/></svg>
        View Absences
      </a>

      <a href="logout.php" title="Logout" style="margin-top:10px;color:var(--danger);">
        <svg viewBox="0 0 24 24" fill="currentColor"><path d="M16 13v-2H7V8l-5 4 5 4v-3zM20 3h-8v2h8v14h-8v2h8a2 2 0 002-2V5a2 2 0 00-2-2z"/></svg>
        Logout
      </a>
    </div>

    <div class="closeBtn" id="closeSidebar" title="Close sidebar">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"/></svg>
    </div>
  </aside>

  <!-- MAIN CONTENT -->
  <main class="main" id="mainContent">
    <div class="topbar">
      <div class="top-left">
        <div class="menuBtn" id="openSidebar" title="Open sidebar">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M3 6h18v2H3zM3 11h18v2H3zM3 16h18v2H3z"/></svg>
        </div>
        <div style="margin-left:12px">
          <h2 style="margin:0">Tableau de bord</h2>
          <small style="color:var(--muted)">Bienvenue — aperçu rapide du système</small>
        </div>
      </div>

      <div class="userBox">
        <button id="darkToggle" class="menuBtn" title="Toggle dark mode">🌓</button>
        <div style="text-align:right">
          <div style="font-weight:700"><?php echo htmlspecialchars($_SESSION['user']); ?></div>
          <a href="logout.php" style="color:var(--danger);text-decoration:none;font-size:13px">Logout</a>
        </div>
        <div class="userAvatar"><?php echo strtoupper(substr($_SESSION['user'],0,1)); ?></div>
      </div>
    </div>

    <!-- MENU big tiles -->
    <section class="grid">
      <a class="menuTile card" href="classes.php">
        <svg width="36" height="36" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L1 7l11 5 9-4.09V17h2V7L12 2z"/></svg>
        <div style="font-size:18px;margin-top:6px">Manage Classes</div>
        <div class="count"><?php echo $total_classes; ?></div>
      </a>

      <a class="menuTile card" href="students.php">
        <svg width="36" height="36" viewBox="0 0 24 24" fill="currentColor"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
        <div style="font-size:18px;margin-top:6px">Manage Students</div>
        <div class="count"><?php echo $total_students; ?></div>
      </a>

      <a class="menuTile card" href="subjects.php">
        <svg width="36" height="36" viewBox="0 0 24 24" fill="currentColor"><path d="M21 3H3v2h18V3zM3 19h18v-2H3v2zM3 7h18v10H3V7z"/></svg>
        <div style="font-size:18px;margin-top:6px">Manage Subjects</div>
        <div class="count"><?php echo $total_subjects; ?></div>
      </a>

      <a class="menuTile card" href="absence_add.php">
        <svg width="36" height="36" viewBox="0 0 24 24" fill="currentColor"><path d="M19 3h-1V1h-2v2H8V1H6v2H5c-1.1 0-2 .9-2 2v14a2 2 0 002 2h14a2 2 0 002-2V5c0-1.1-.9-2-2-2zM7 12h10v2H7z"/></svg>
        <div style="font-size:18px;margin-top:6px">Add Absence</div>
        <div class="count">—</div>
      </a>

      <a class="menuTile card" href="absence_list.php">
        <svg width="36" height="36" viewBox="0 0 24 24" fill="currentColor"><path d="M3 13h8v-2H3v2zm0 6h8v-2H3v2zM3 7h8V5H3v2zm10 6h8v-2h-8v2zm0 6h8v-2h-8v2z"/></svg>
        <div style="font-size:18px;margin-top:6px">View Absences</div>
        <div class="count"><?php echo $total_absences; ?></div>
      </a>
    </section>

    <!-- Charts -->
    <section class="chart-row">
      <div class="chart-card">
        <h3>Absences per Class</h3>
        <canvas id="classChart" aria-label="Absences per Class"></canvas>
      </div>

      <div class="chart-card">
        <h3>Absences per Subject</h3>
        <canvas id="subjectChart" aria-label="Absences per Subject"></canvas>
      </div>
    </section>

  </main>
</div>

<script>
// Sidebar toggle logic
var sidebar = document.getElementById('sidebar');
var openBtn = document.getElementById('openSidebar');
var closeBtn = document.getElementById('closeSidebar');
openBtn.addEventListener('click', function(){ sidebar.classList.toggle('open'); });
closeBtn.addEventListener('click', function(){ sidebar.classList.remove('open'); });

// Close sidebar when clicking outside on small screens
document.addEventListener('click', function(e){
  var isClickInside = sidebar.contains(e.target) || openBtn.contains(e.target);
  if(!isClickInside && window.innerWidth < 900){
    sidebar.classList.remove('open');
  }
});

// Dark mode toggle (simple)
var darkToggle = document.getElementById('darkToggle');
darkToggle.addEventListener('click', function(){
  document.body.classList.toggle('dark');
  if(document.body.classList.contains('dark')) localStorage.setItem('dark','1');
  else localStorage.removeItem('dark');
});
if(localStorage.getItem('dark')) document.body.classList.add('dark');

// Charts data from PHP
var classLabels = <?php echo json_encode($class_labels); ?>;
var classCounts = <?php echo json_encode($class_counts); ?>;
var subjectLabels = <?php echo json_encode($subject_labels); ?>;
var subjectCounts = <?php echo json_encode($subject_counts); ?>;

// Render charts
var c1 = document.getElementById('classChart').getContext('2d');
new Chart(c1, {
  type:'bar',
  data:{
    labels: classLabels,
    datasets:[{
      label:'Absences',
      data: classCounts,
      backgroundColor: 'rgba(13,110,253,0.8)',
      borderRadius:6,
      barThickness:28
    }]
  },
  options:{responsive:true,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true}}}
});

var c2 = document.getElementById('subjectChart').getContext('2d');
new Chart(c2, {
  type:'bar',
  data:{
    labels: subjectLabels,
    datasets:[{
      label:'Absences',
      data: subjectCounts,
      backgroundColor: 'rgba(16,185,129,0.85)',
      borderRadius:6,
      barThickness:28
    }]
  },
  options:{responsive:true,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true}}}
});
</script>
</body>
</html>
