<?php
session_start();
require 'db.php';

if(!isset($_SESSION['user'])){
    header("Location: login.php");
    exit;
}
$CURRENT_USER = $_SESSION['user'];

// Ajouter un étudiant
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['full_name'], $_POST['class_id'])){
    $name = trim($_POST['full_name']);
    $class_id = (int)$_POST['class_id'];
    if($name!==''){
        $stmt = $conn->prepare("INSERT INTO students(full_name, class_id) VALUES(?, ?)");
        $stmt->bind_param("si",$name,$class_id);
        $stmt->execute();
        header("Location: students.php");
        exit;
    }
}

// Supprimer un étudiant
if(isset($_GET['delete'])){
    $id = (int)$_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM students WHERE id=?");
    $stmt->bind_param("i",$id);
    $stmt->execute();

    header("Location: students.php");
    exit;
}

// Récupérer étudiants
// Récupérer les étudiants
$students = $conn->query("
    SELECT students.id, students.full_name, classes.class_name
    FROM students
    LEFT JOIN classes ON students.class_id = classes.id
    ORDER BY students.id DESC
");


if(!$students){ die("Erreur SQL: ".$conn->error); }
$total_students = $students->num_rows;

// Classes pour le dropdown
$classes = $conn->query("SELECT id,class_name FROM classes ORDER BY class_name ASC");
if(!$classes){ die("Erreur SQL: ".$conn->error); }
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Manage Students — AbsenceSys</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
:root{
  --bg:#f4f6f8; --card:#ffffff; --muted:#6b7280; --primary:#0d6efd; --accent:#10b981; --danger:#ef4444; --text:#111827;
}
body.dark{--bg:#0b1220; --card:#071025; --muted:#94a3b8; --primary:#60a5fa; --accent:#34d399; --danger:#fb7185; --text:#e6eef8;}
*{box-sizing:border-box}
html,body{height:100%;margin:0;font-family:Inter,Segoe UI,Roboto,Arial,sans-serif;background:var(--bg);color:var(--text);background-color: lightblue}
.container{display:flex;min-height:100vh;}
.sidebar{position:fixed;left:0;top:0;bottom:0;width:260px;background:linear-gradient(180deg, rgba(255,255,255,0.03), rgba(255,255,255,0.01));backdrop-filter: blur(6px);transform:translateX(-320px);transition:transform .28s ease, box-shadow .28s;padding:22px;z-index:40;box-shadow: 0 10px 30px rgba(2,6,23,0.18);}
.sidebar.open{transform:translateX(0);}
.brand{display:flex;align-items:center;gap:12px;margin-bottom:18px}
.brand .logo{width:46px;height:46px;border-radius:10px;background:linear-gradient(135deg,var(--primary),var(--accent));display:flex;align-items:center;justify-content:center;color:white;font-weight:700}
.brand h3{margin:0;font-size:18px}
.sidebar .nav{margin-top:12px;display:flex;flex-direction:column;gap:8px}
.nav a{display:flex;align-items:center;gap:12px;padding:12px;border-radius:10px;color:var(--text);text-decoration:none;font-weight:600;transition:background .18s,color .18s,transform .12s;}
.nav a.active{background:var(--primary);color:white;box-shadow:0 6px 18px rgba(13,110,253,0.12)}
.main{margin-left:0;width:100%;padding:26px;transition:margin-left .28s ease;min-height:100vh;}
.sidebar.open ~ .main{margin-left:260px}
.topbar{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:18px}
.top-left{display:flex;align-items:center;gap:12px}
.menuBtn{background:var(--card);border-radius:10px;padding:10px;cursor:pointer;box-shadow:0 6px 18px rgba(2,6,23,0.06)}
.userBox{display:flex;align-items:center;gap:12px}
.userAvatar{width:44px;height:44px;border-radius:10px;background:linear-gradient(135deg,var(--primary),var(--accent));display:flex;align-items:center;justify-content:center;color:white;font-weight:700}
.grid{display:grid;grid-template-columns: repeat(auto-fit,minmax(220px,1fr));gap:18px;margin-bottom:20px}
.card{background:var(--card);padding:20px;border-radius:14px;box-shadow:0 6px 24px rgba(2,6,23,0.06)}
.menuTile{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;padding:28px;border-radius:12px;text-decoration:none;color:var(--text);background:linear-gradient(180deg, transparent, rgba(0,0,0,0.01));transition:transform .12s ease,box-shadow .12s ease,background .12s;text-align:center;font-weight:700;min-height:120px;cursor:pointer;}
.menuTile:hover{transform:translateY(-6px);box-shadow:0 12px 30px rgba(2,6,23,0.08);background:rgba(0,0,0,0.02)}
.search-input{padding:10px;border-radius:8px;border:1px solid #ddd;}
.add-btn{padding:10px 15px;border-radius:8px;background:var(--primary);color:white;border:none;cursor:pointer;transition:0.3s;}
.add-btn:hover{background:#0056b3;}
.table{width:100%;border-collapse:collapse;margin-top:12px;}
.table th,.table td{padding:12px;text-align:left;border-bottom:1px solid #ddd;}
.table th{background:rgba(0,0,0,0.03);}
.actions a{color:var(--danger);text-decoration:none;}
</style>
</head>
<body>
<div class="container">

<!-- Sidebar -->
<aside class="sidebar" id="sidebar">
  <div class="brand"><div class="logo">AS</div><h3>AbsenceSys</h3></div>
  <div class="nav">
    <a href="dashboard.php" title="Dashboard">Dashboard</a>
    <a href="students.php" class="active" title="Students">Students</a>
    <a href="classes.php" title="Classes">Classes</a>
    <a href="subjects.php" title="Subjects">Subjects</a>
    <a href="logout.php" style="color:var(--danger)">Logout</a>
  </div>
</aside>

<!-- Main -->
<main class="main">
<div class="topbar">
  <div class="top-left">
    <div class="menuBtn" id="openSidebar">☰</div>
    <div style="margin-left:12px">
      <h2 style="margin:0">Manage Students</h2>
      <small style="color:var(--muted)">Ajouter, supprimer et gérer les étudiants</small>
    </div>
  </div>
  <div class="userBox">
    <div style="font-weight:700"><?= htmlspecialchars($CURRENT_USER) ?></div>
    <a href="logout.php" style="color:var(--danger);text-decoration:none;font-size:13px;margin-left:8px;">Logout</a>
    <div class="userAvatar"><?= strtoupper(substr($CURRENT_USER,0,1)) ?></div>
  </div>
</div>

<!-- Add Student -->
<section class="grid">
  <div class="menuTile card" onclick="document.getElementById('addBox').style.display='block'">
    <div style="font-size:18px;margin-top:6px">+ Add Student</div>
    <div class="count"><?= $total_students ?></div>
  </div>
</section>

<div class="card" id="addBox" style="display:none;margin-top:15px;">
  <form method="POST" style="display:flex;gap:8px;flex-wrap:wrap;">
    <input type="text" name="student_name" placeholder="Student name" required class="search-input">
    <select name="class_id" required class="search-input">
      <option value="">Select class</option>
      <?php while($c = $classes->fetch_assoc()): ?>
        <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['class_name']) ?></option>
      <?php endwhile; ?>
    </select>
    <button type="submit" class="add-btn">Save</button>
    <button type="button" onclick="document.getElementById('addBox').style.display='none'" style="padding:10px;border-radius:8px;border:1px solid #ddd;">Cancel</button>
  </form>
</div>

<!-- Students Table -->
<div class="card" style="margin-top:15px;">
  <table class="table">
    <thead>
      <tr><th>ID</th><th>Student Name</th><th>Class</th><th>Actions</th></tr>
    </thead>
    <tbody>
      <?php while($row=$students->fetch_assoc()): ?>
        <tr>
          <td><?= $row['id'] ?></td>
          <td><?= htmlspecialchars($row['full_name']) ?></td>
          <td><?= htmlspecialchars($row['class_name']) ?></td>
          <td class="actions">
            <a href="students.php?delete=<?= $row['id'] ?>" onclick="return confirm('Delete student?')">Delete</a>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

</main>
</div>

<script>
var sidebar=document.getElementById('sidebar');
document.getElementById('openSidebar').addEventListener('click',()=>{sidebar.classList.toggle('open');});
</script>
</body>
</html>
